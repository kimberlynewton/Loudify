const http = require("http"); // Importing necessary modules
const url = require("url");

const genres = require("./models/genre"); // Importing genre model to interact with genres data
const songs = require("./models/song"); // Importing song model to interact with songs data

const DEFAULT_HEADER = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
};

async function handleGetRequest(req, res) {
  try {
    const parsedUrl = url.parse(req.url, true); // Parsing the URL to extract query parameters
    const path = parsedUrl.pathname; // Extracting the path from the URL

    if (path === "/genres") {
      const data = await genres.findAll(); // Interacting with genres model to fetch all genres
      res.writeHead(200, DEFAULT_HEADER); // Setting response header
      res.end(JSON.stringify({ results: data, totalResults: data.length })); // Sending JSON response with genres
      return; // Exiting after handling /genres
    }

    if (path === "/songs") {
      const { q, field, page = 1, limit = 50 } = parsedUrl.query; // Extracting query parameters
      let data;

      switch (field) {
        case "title":
          // Searching songs by title using the songs model
          data = await songs.searchByTitle(q, Number(page), Number(limit));
          break;
        case "album":
          data = await songs.searchByAlbum(q, Number(page), Number(limit));
          break;
        case "artist":
          data = await songs.searchByArtist(q, Number(page), Number(limit));
          break;
        // Additional cases for 'genre', 'year' as per project requirements
        default:
          data = await songs.findAll(Number(page), Number(limit));
          break;
      }
      console.log(data);
      res.writeHead(200, DEFAULT_HEADER); // Setting response header
      res.end(
        JSON.stringify({
          results: data.results,
          page,
          limit,
          totalResults: data.results.length,
        })
      ); // Sending JSON response with song data
      return; // Exiting after handling /songs
    }

    // Handling 404 Not Found for any other paths
    res.writeHead(404, DEFAULT_HEADER);
    res.end("URL Not Found");
  } catch (error) {
    // Handling server errors
    if (!res.headersSent) {
      res.writeHead(500, DEFAULT_HEADER);
      res.end(`Server error: ${error.message}`);
    }
  }
}

const server = http.createServer((req, res) => {
  if (req.method === "GET") {
    handleGetRequest(req, res); // Handling GET requests
  } else {
    // Handling unsupported methods (405 Method Not Allowed)
    res.writeHead(405, DEFAULT_HEADER);
    res.end(`Method not allowed: ${req.method}`);
  }
});

const PORT = 3000;
server.listen(PORT, () => {
  // Server starts listening on specified port
  console.log(`Server is listening on http://localhost:${PORT}`);
});
