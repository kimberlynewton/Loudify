console.log('Node.js is working in the server directory!');
