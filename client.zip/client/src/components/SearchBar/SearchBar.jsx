import React, { useState } from "react";
import styles from "./SearchBar.module.css";
import ClearIcon from "../Icons/ClearIcon";

function SearchBar({ onSearch }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchField, setSearchField] = useState("title");

  const handleSearch = () => {
    onSearch(searchTerm, searchField);
  };

  const handleClearSearch = () => {
    setSearchTerm("");
  };

  return (
    <header className={styles.header}>
      {/* This is where the user types their search term. */}
      <div className={styles.inputwrapper}>
        <input
          type="text"
          className={styles.searchInput}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search for songs"
        />
        {/* This "X" appears when there's text in the input, and clicking it clears the text. */}
        {searchTerm && ( // Show the clear icon only when there is text to clear
          <span className={styles.clearIcon} onClick={handleClearSearch}>
            <ClearIcon></ClearIcon>
          </span>
        )}
      </div>
      {/* These are the buttons that let the user specify what category they're searching in. */}
      <div className={styles.chipButtons}>
        <button
          className={`${styles.chip} ${
            searchField === "title" ? styles.activeChip : ""
          }`}
          onClick={() => setSearchField("title")}
        >
          Title
        </button>
        <button
          className={`${styles.chip} ${
            searchField === "album" ? styles.activeChip : ""
          }`}
          onClick={() => setSearchField("album")}
        >
          Album
        </button>
        <button
          className={`${styles.chip} ${
            searchField === "artist" ? styles.activeChip : ""
          }`}
          onClick={() => setSearchField("artist")}
        >
          Artist
        </button>
        <button
          className={`${styles.chip} ${
            searchField === "genre" ? styles.activeChip : ""
          }`}
          onClick={() => setSearchField("genre")}
        >
          Genre
        </button>
      </div>
      {/* This is the search button the user clicks to start the search. */}
      <button className={styles.searchButton} onClick={handleSearch}>
        Search
      </button>
    </header>
  );
}
// This line makes the SearchBar component available for use elsewhere in the app.
export default SearchBar;
