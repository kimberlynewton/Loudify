import React from 'react';
import Song from '../Song/Song'; // Import the Song component
import styles from "./SongList.module.css"; // Import existing styles

function SongList({ songs }) {
  // Takes 'songs' as a prop - an array of song objects
  return (
    <section className={styles.container}>
      <table className={styles.table}>
        {/* Table headers */}
        <thead>
          <tr>
            <th>Title</th>
            <th>Album</th>
            <th>Year</th>
            <th>Genre</th>
            <th>Duration</th>
          </tr>
        </thead>
        <tbody>
          {songs.map(song => {  // Render a Song component for each song
          console.log(song.id)
           return <Song key={song.id} song={song} />
          })} 
            
          
            
            
        </tbody>
      </table>
    </section>
  );
}

export default SongList;

