import React, { useState, useEffect } from "react";
import styles from "./App.module.css";
import SongList from "../songlist/SongList";
import SearchBar from "../searchbar/SearchBar";
import SearchIcon from "../Icons/SearchIcon";
import ClearIcon from "../Icons/ClearIcon";
import ClockIcon from "../Icons/ClockIcon";

function App() {
  const [songs, setSongs] = useState([]); // Creates a state variable songs that's initialized as an empty array. setSongs is the function you'll use to update songs

  useEffect(() => {
    // Fetch songs from the server when the component mounts. The fetched data updates the songs state with setSongs, causing the component to re-render and display the fetched songs.
    fetch("http://localhost:3000/songs")
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        setSongs(data.results); // Update state with fetched songs
      })
      .catch((error) => {
        console.error("Error fetching songs:", error);
      });
  }, []);

  const handleSearch = (searchTerm, searchField) => {
    // Function to handle search logic
    fetch(
      `http://localhost:3000/songs?q=${encodeURIComponent(
        searchTerm
      )}&field=${encodeURIComponent(searchField)}`
    )
      .then((response) => response.json())
      .then((data) => {
        setSongs(data.results); // Update the songs state with the fetched data
      })
      .catch((error) => {
        console.error("Error performing search:", error);
      });
  };

  return (
    <div className={styles.App}>
      <SearchBar onSearch={handleSearch} />
      <SongList songs={songs} />
      <div></div>
    </div>
  );
}

export default App;
