import React from 'react';
import styles from './Song.module.css';

function Song({ song }) {
  // Destructuring the song object to extract the needed properties
  const { coverImage, title, artist, album, year, genre, duration } = song;

  return (
    <tr className={styles.row}>
      {/* Cover image as a thumbnail */}
      <td>
        <div className={styles.titleContent}>
          <div className={styles.imageWrapper}>
            <img src={coverImage} alt={title} className={styles.image} />
          </div>
          <div>
            <div className={styles.songTitle}>{title}</div>
            <div>{artist}</div>
          </div>
        </div>
      </td>
      {/* Other song details */}
      <td>{album}</td>
      <td>{year}</td>
      <td>{genre.join(', ')}</td>
      <td>{duration}</td>
    </tr>
  );
}

export default Song;
